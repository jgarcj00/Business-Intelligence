class MinerWallet extends Wallet {
    MinerWallet(){
        generateKeyPair();
    }
}
